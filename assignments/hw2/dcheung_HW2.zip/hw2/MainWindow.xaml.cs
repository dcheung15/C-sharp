﻿//Author: Dounglan Cheung
//4.8.2021
//CSE 483
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace hw2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Model _model;
        public int _buttonPresses;
        public MainWindow()
        {
            InitializeComponent();
            // make it so the user cannot resize the window
            this.ResizeMode = ResizeMode.NoResize;
            _model = new Model();
            this.DataContext = _model;
            /* associate ItemControl with collection. This collection contains the tiles we placed in the ItemsControl
            the data in the Tile Colleciton will be bound to each of the UI elements on the display */
            MyItemsControl.ItemsSource = _model.TileCollection;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var selectedButton = e.OriginalSource as FrameworkElement;
            if (selectedButton != null)
            {
                // get the currently selected item in the collection which we know to be a Tile object
                var currentTile = selectedButton.DataContext as Tile;
                if (currentTile.Pressed == false)
                {
                    _buttonPresses++;
                    currentTile.ButtonPresses = _buttonPresses;
                }
                _model.UserSelection(currentTile.TileName, _buttonPresses);
            }
        }

        private void Play_Button_Click(object sender, RoutedEventArgs e)
        {
            _model.Clear();
        }

    }
}
