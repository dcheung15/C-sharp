﻿//Author: Dounglan Cheung
//4.8.2021
//CSE 483
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Collections.ObjectModel;
using System.ComponentModel;


namespace hw2
{
    class Model : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public ObservableCollection<Tile> TileCollection;
        private static UInt32 _numTiles = 9;
        public Boolean pressed = false;
        public int counter = 0;
        private String _statusText = "";
        public String StatusText

        {
            get { return _statusText; }
            set
            {
                _statusText = value;
                OnPropertyChanged("StatusText");
            }
        }

        public Model()
        {
            TileCollection = new ObservableCollection<Tile>();
            for (int i = 0; i < _numTiles; i++)
            {
                TileCollection.Add(new Tile()
                {
                    TileBrush = Brushes.Black,
                    TileLabel = " ",
                    TileName = i.ToString(),
                    TileBackground = Brushes.Pink
                });
            }
        }

        public Boolean winner = false;
        // processes all buttons. called from view when a button is clicked
        public void UserSelection(String buttonSelected, int _buttonPresses)
        {
            int index = int.Parse(buttonSelected);
            if (!winner)
            {
                if (_buttonPresses % 2 != 0 && !TileCollection[index].Pressed)
                {
                    TileCollection[index].TileLabel = "X";
                    TileCollection[index].TileBrush = Brushes.Green;
                    TileCollection[index].Pressed = true;

                    StatusText = "User Selected Button " + index.ToString() + "\n" + "It is O's Turn";
                    counter++;
                    if (_buttonPresses > 4)
                        WinnerSelection();
                }
                else if (!TileCollection[index].Pressed)
                {
                    TileCollection[index].TileLabel = "O";
                    TileCollection[index].TileBrush = Brushes.Red;
                    TileCollection[index].Pressed = true;

                    StatusText = "User Selected Button " + index.ToString() + "\n" + "It is X's Turn";
                    counter++;
                    if (_buttonPresses > 4)
                        WinnerSelection();
                }
                else if (TileCollection[index].Pressed)
                {
                    StatusText = "This button has alredy been selected.";
                }
            }
        }

        // Resets all buttons back to their starting point
        public void Clear()
        {
            for (int x = 0; x < _numTiles; x++)
            {
                TileCollection[x].TileBrush = Brushes.Black;
                TileCollection[x].TileLabel = " ";
                TileCollection[x].ButtonPresses = 0;
                TileCollection[x].Pressed = false;
            }
            winner = false;
            counter = 0;
            StatusText = "New Game!";
        }

        // Logic for wins and ties
        public Boolean WinnerSelection()
        {
            if ((TileCollection[0].TileLabel == TileCollection[1].TileLabel && TileCollection[1].TileLabel == TileCollection[2].TileLabel) && (TileCollection[2].TileLabel != " "))
            {
                winner = true;
                TileCollection[0].TileBrush = Brushes.Navy;
                TileCollection[1].TileBrush = Brushes.Navy;
                TileCollection[2].TileBrush = Brushes.Navy;
                StatusText = TileCollection[0].TileLabel + " won on First Row!\n^_^";
            }
            else if ((TileCollection[3].TileLabel == TileCollection[4].TileLabel && TileCollection[4].TileLabel == TileCollection[5].TileLabel) && (TileCollection[3].TileLabel != " "))
            {
                winner = true;
                TileCollection[3].TileBrush = Brushes.Navy;
                TileCollection[4].TileBrush = Brushes.Navy;
                TileCollection[5].TileBrush = Brushes.Navy;
                StatusText = TileCollection[3].TileLabel + " won on Second Row!\n^_^";
            }
            else if ((TileCollection[6].TileLabel == TileCollection[7].TileLabel && TileCollection[7].TileLabel == TileCollection[8].TileLabel) && (TileCollection[6].TileLabel != " "))
            {
                winner = true;
                TileCollection[6].TileBrush = Brushes.Navy;
                TileCollection[7].TileBrush = Brushes.Navy;
                TileCollection[8].TileBrush = Brushes.Navy;
                StatusText = TileCollection[6].TileLabel + " won on Third Row!\n^_^";
            }
            else if ((TileCollection[0].TileLabel == TileCollection[3].TileLabel && TileCollection[3].TileLabel == TileCollection[6].TileLabel) && (TileCollection[0].TileLabel != " "))
            {
                winner = true;
                TileCollection[0].TileBrush = Brushes.Navy;
                TileCollection[3].TileBrush = Brushes.Navy;
                TileCollection[6].TileBrush = Brushes.Navy;
                StatusText = TileCollection[0].TileLabel + " won on First Column!\n^_^";
            }
            else if ((TileCollection[1].TileLabel == TileCollection[4].TileLabel && TileCollection[4].TileLabel == TileCollection[7].TileLabel) && (TileCollection[1].TileLabel != " "))
            {
                winner = true;
                TileCollection[1].TileBrush = Brushes.Navy;
                TileCollection[4].TileBrush = Brushes.Navy;
                TileCollection[7].TileBrush = Brushes.Navy;
                StatusText = TileCollection[1].TileLabel + " won on Second Column!\n^_^";
            }
            else if ((TileCollection[2].TileLabel == TileCollection[5].TileLabel && TileCollection[5].TileLabel == TileCollection[8].TileLabel) && (TileCollection[2].TileLabel != " "))
            {
                winner = true;
                TileCollection[2].TileBrush = Brushes.Navy;
                TileCollection[7].TileBrush = Brushes.Navy;
                TileCollection[8].TileBrush = Brushes.Navy;
                StatusText = TileCollection[2].TileLabel + " won on Third Column!\n^_^";
            }
            else if ((TileCollection[0].TileLabel == TileCollection[4].TileLabel && TileCollection[4].TileLabel == TileCollection[8].TileLabel) && (TileCollection[0].TileLabel != " "))
            {
                winner = true;
                TileCollection[0].TileBrush = Brushes.Navy;
                TileCollection[4].TileBrush = Brushes.Navy;
                TileCollection[8].TileBrush = Brushes.Navy;
                StatusText = TileCollection[0].TileLabel + " won on Diagonal Row!\n^-^";
            }
            else if ((TileCollection[2].TileLabel == TileCollection[4].TileLabel && TileCollection[4].TileLabel == TileCollection[6].TileLabel) && (TileCollection[2].TileLabel != " "))
            {
                winner = true;
                TileCollection[2].TileBrush = Brushes.Navy;
                TileCollection[4].TileBrush = Brushes.Navy;
                TileCollection[6].TileBrush = Brushes.Navy;
                StatusText = TileCollection[2].TileLabel + " won on Inverse Diagonal Row!\n^_^";
            }
            else if (counter == 9 && winner == false) //draw
            {
                winner = false;
                for (int x = 0; x < _numTiles; x++)
                {
                    TileCollection[x].TileBrush = Brushes.White;
                }
                StatusText = "It's a Draw. \n:o";
            }
            return winner;
        }
    }
}
