﻿//Hongyi Ruan, Dounglan Cheung
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Threading;
using System.Threading;
using System.Timers;
using HighPrecisionTimer;
using System.Net.Sockets;
using System.Net;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows;
using System.Collections.ObjectModel;

namespace DigitalClock
{
    public partial class Model : INotifyPropertyChanged
    {
        // LEDs
        public ObservableCollection<LED> LED;

        // data that keeps track of ports and addresses
        private static int _localPort = 5000;
        private static string _localIPAddress = "127.0.0.1";
        // Check bool to tell when the 24 hour box is checked
        bool milCheck;
        // Alarm bool to tell when the Alarm is being sent from the application
        int alarm = 0;

        // DLL Imports
        public static TimeDataDLL.TimeData.StructTimeData _currTime; // Current Time
        public static TimeDataDLL.TimeData.StructTimeData _setTime;  // Set the time
        public static TimeDataDLL.TimeData.StructTimeData _alarm;    // Alarm

        //thread that runs to receive data
        private Thread _receiveDataThread;

        UdpClient _dataSocket;
        Stopwatch stopWatch;
        bool _netTimerTimerRunning = false;
        System.Timers.Timer dotNetTimerTimer;

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        // Alarm Label to display the alarm
        private string _alarmLabel;
        public string AlarmLabel
        {
            get { return _alarmLabel; }
            set
            {
                _alarmLabel = value;
                OnPropertyChanged("AlarmLabel");
            }
        }

        // AM PM Label
        private string _AmPm;
        public string AmPm
        {
            get { return _AmPm; }
            set
            {
                _AmPm = value;
                OnPropertyChanged("Am/Pm");
            }
        }
        // Function to recieve data from the Clock App
        private void ReceiveThreadFunction()
        {
            // Create the endpoint
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(_localIPAddress), (int)_localPort);
            while (true)
            {
                try
                {
                    Byte[] receiveData = _dataSocket.Receive(ref endPoint);
                    // receiveData[3] == 0 is set time, if the byte = 3
                    if (receiveData[3] == 0)
                    {
                        _setTime = new TimeDataDLL.TimeData.StructTimeData(receiveData[0], receiveData[1], receiveData[2]);
                        _currTime = _setTime;
                    }
                    //receiveData[3] == 1 is current time
                    else if (receiveData[3] == 1)
                    {
                        DateTime currTime = DateTime.Now;
                        _currTime = new TimeDataDLL.TimeData.StructTimeData(currTime.Hour, currTime.Minute, currTime.Second);
                    }
                    // receivedata[5] is alarm. = 1 means alarm is set. 
                    else if (receiveData[5] == 1)
                    {
                        _alarm = new TimeDataDLL.TimeData.StructTimeData(receiveData[0], receiveData[1], receiveData[2]);
                        alarm = 1; // Alarm flag for use in timeUpdate()
                    }
                    // receiveData[4] is for checking whether it is 24 hrs or not
                    milCheck = (receiveData[4] != 0);
                }
                catch (SocketException ex)
                {
                    Console.WriteLine(ex.ToString());
                    return;
                }
            }
        }

        public void NETTimerTimerStart(bool start) 
        {
            if (start == true)
            {
                dotNetTimerTimer = new System.Timers.Timer(1000);
                dotNetTimerTimer.Elapsed += new ElapsedEventHandler(NetTimerTimerHandler); //how long it's been since timer set
                dotNetTimerTimer.Start(); // starts timer
            }
            else if (_netTimerTimerRunning)
            {
                dotNetTimerTimer.Stop();
            }
        }

        private void NetTimerTimerHandler(object source, ElapsedEventArgs e)
        {
            // updates each tick
            timeUpdate();
            getDigit(_currTime);
        }
        
        void getDigit(TimeDataDLL.TimeData.StructTimeData _currTimeInput)//gets the digits for the LEDs and displays them
        {   
            // 24 hours
            if (milCheck)
            {
                LED[0].LEDValue = (UInt32)(_currTimeInput.hour % 100) / 10;
                LED[1].LEDValue = (UInt32)(_currTimeInput.hour % 10);
                LED[2].LEDValue = (UInt32)(_currTimeInput.minute % 100) / 10;
                LED[3].LEDValue = (UInt32)(_currTimeInput.minute % 10);
                LED[4].LEDValue = (UInt32)(_currTimeInput.second % 100) / 10;
                LED[5].LEDValue = (UInt32)(_currTimeInput.second % 10);
            }
            // 12 hours
            else if (!milCheck)
            {
                UInt32 x;
                if (_currTimeInput.hour > 12)
                {
                    x = (UInt32)_currTimeInput.hour - 12;
                }
                else if (_currTimeInput.hour <= 12)
                {
                    x = (UInt32)_currTimeInput.hour;
                }
                else
                {
                    x = 0;
                }

                LED[0].LEDValue = (UInt32)(x % 100) / 10;
                LED[1].LEDValue = (UInt32)(x % 10);
                LED[2].LEDValue = (UInt32)(_currTimeInput.minute % 100) / 10;
                LED[3].LEDValue = (UInt32)(_currTimeInput.minute % 10);
                LED[4].LEDValue = (UInt32)(_currTimeInput.second % 100) / 10;
                LED[5].LEDValue = (UInt32)(_currTimeInput.second % 10);
            }
        }

        // Time update function - Tracks seconds, sets off alarm
        private void timeUpdate()
        {
            if (_currTime.second >= 59)
            {
                _currTime.minute++;
                _currTime.second = 0;
            }
            else
            {
                _currTime.second++;
            }
            if (_currTime.minute > 59)
            {
                _currTime.hour++;
                _currTime.minute = 0;
            }
            if (_currTime.hour == 23 && _currTime.minute == 59 && _currTime.second == 59)
            {
                _currTime.second = 0;
                _currTime.minute = 0;
                _currTime.hour = 0;
            }
            // If alarm is received, call AlarmUpdate
            if (alarm == 1)
            {
                AlarmUpdate(_currTime, _alarm);
            }
        }

        // Alarm Update Function
        private void AlarmUpdate(TimeDataDLL.TimeData.StructTimeData setTime, TimeDataDLL.TimeData.StructTimeData AlarmTime)
        {
            bool alarmflag = false;

            if (!milCheck)
            {
                if (setTime.hour > 12)
                {
                    setTime.hour -= 12;
                }
            }

            // alarm goes off when it is exactly the time that is set at
            try
            {   
                if ((setTime.hour == _alarm.hour) && (setTime.minute == _alarm.minute) && (setTime.second == _alarm.second))
                {
                    alarmflag = true;
                }

                if (alarmflag == true)
                {
                    AlarmLabel = "ALARM";
                }
                else
                {
                    AlarmLabel = null;
                }
                
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public Model()
        {
            _dataSocket = new UdpClient(_localPort);

            // start UDP thread
            ThreadStart threadFunction = new ThreadStart(ReceiveThreadFunction);
            _receiveDataThread = new Thread(threadFunction);
            _receiveDataThread.Start();

            // from TimerDemo Model.cs 
            stopWatch = new Stopwatch();
            stopWatch.Start();
            NETTimerTimerStart(true);
        }

        public void Cleanup()
        {
            stopWatch.Stop();
            NETTimerTimerStart(false);

            if (_dataSocket != null) _dataSocket.Close(); //closes socket
            if (_receiveDataThread != null) _receiveDataThread.Abort(); 
        }

        public void InitModel()
        {
            LED = new ObservableCollection<LED>();

            // Adding to LED observable collection
            for (int i = 0; i < 6; ++i)
            {
                LED.Add(new LED()
                {
                    LEDLeft = 60 * i,
                    LEDTop = 60,
                    LEDValue = 0,
                });
            }
        }

    }
}
