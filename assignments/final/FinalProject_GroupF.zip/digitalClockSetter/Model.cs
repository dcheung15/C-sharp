﻿// Dounglan Cheung and Hongyi Ruan
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.ComponentModel;

namespace digitalClockSetter
{
    class Model : INotifyPropertyChanged
    {
        // data that keeps track of ports and addresses
        private static UInt32 _remotePort = 5000;
        private static String _remoteIPAddress = "127.0.0.1";
        
        // this is the UDP socket that will be used to communicate over the network
        private UdpClient _dataSocket;

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public int _hours;
        public int hoursBox
        {
            get { return _hours; }
            set
            {
                _hours = value;
                OnPropertyChanged("Hours");
            }
        }

        public int _minutes;
        public int minutesBox
        {
            get { return _minutes; }
            set
            {
                _minutes = value;
                OnPropertyChanged("Minutes");
            }
        }

        public int _seconds;
        public int secondsBox
        {
            get { return _seconds; }
            set
            {
                _seconds = value;
                OnPropertyChanged("Seconds");
            }
        }

        public int _alarm;
        public int Alarm
        {
            get { return _alarm; }
            set
            {
                _alarm = value;
                OnPropertyChanged("Alarm");
            }
        }

        public bool _checkBox;
        public bool CheckBox
        {
            get { return _checkBox; }
            set
            {
                _checkBox = value;
                OnPropertyChanged("CheckBox");
            }
        }

        public Model()
        {
            try
            {
                _dataSocket = new UdpClient();
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
        }

        public void sendData(string button)
        {
            var client = new UdpClient();
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 5000);
            int buttonSelect = 2;
            client.Connect(ep);

            if (button == "Set Time")
            {
                buttonSelect = 0;
            }
            if (button == "Current Time")
            {
                buttonSelect = 1;
            }
            if (button == "Set Alarm")
            {
                _alarm = 1;
            }

            Byte[] sendData = { (Byte)_hours, (Byte)_minutes, (Byte)_seconds, (Byte)buttonSelect, (Byte)Convert.ToInt32(CheckBox), (Byte)_alarm };

            try
            {
                _dataSocket.Send(sendData, sendData.Length, ep);
            }
            catch (SocketException ex)
            {
                Console.WriteLine(ex.ToString());
                return;
            }
        }

    }
}
