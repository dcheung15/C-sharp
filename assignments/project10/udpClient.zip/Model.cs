﻿//Hongyi Ruan and Dounglan Cheng


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Sockets
using System.Net.Sockets;
using System.Net;

// INotifyPropertyChanged
using System.ComponentModel;


namespace ExampleUdpClient
{
    class Model : INotifyPropertyChanged
    {
        // some data that keeps track of ports and addresses
        private static UInt32 _remotePort = 5000;
        private static String _remoteIPAddress = "127.0.0.1";

        private static int _localPort = 5000;
        private static string _localIPAddress = "127.0.0.1";

        // this is the UDP socket that will be used to communicate
        // over the network
        private UdpClient _dataSocket;


        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private String _myFriendBox;
        public String MyFriendBox
        {
            get { return _myFriendBox; }
            set
            {
                _myFriendBox = value;
                OnPropertyChanged("MyFriendBox");
            }
        }

        private String _statusBox;
        public String StatusBox
        {
            get { return _statusBox; }
            set
            {
                _statusBox = value;
                OnPropertyChanged("StatusBox");
            }
        }

        private String _loopback;
        public String Loopback
        {
            get { return _loopback; }
            set
            {
                _loopback = value;
                OnPropertyChanged("Loopback");
            }
        }

        public Model()
        {
            try
            {
                // set up generic UDP socket and bind to local port
                //
                _dataSocket = new UdpClient();
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
        }

        public void SendMessage()
        {
            IPEndPoint remoteHost = new IPEndPoint(IPAddress.Parse(_remoteIPAddress), (int)_remotePort);
            Byte[] sendBytes = Encoding.ASCII.GetBytes(MyFriendBox);

            try
            {
                _dataSocket.Send(sendBytes, sendBytes.Length, remoteHost);
            }
            catch (SocketException ex)
            {
                StatusBox = StatusBox + DateTime.Now + ":" + ex.ToString();
                return;
            }

            StatusBox += DateTime.Now + ":" + "Message Sent Successfully" + "\n";

            Byte[] receiveData = _dataSocket.Receive(ref remoteHost);
            try
            {
                Loopback = System.Text.Encoding.Default.GetString(receiveData);
            }
            catch (SocketException ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

    }
}
